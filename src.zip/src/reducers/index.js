import { combinedReducers } from 'redux';
export default combinedReducers({
    libraries: () => []
});